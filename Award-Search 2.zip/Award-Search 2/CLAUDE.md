# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a USA Spending Award Search application that provides a web interface for searching government awards (contracts, grants, IDVs) via the USASpending.gov API. The application runs in an Nginx container and includes test coverage via Jest.

## Development Commands

### Docker Operations
- **Build and start**: `docker-compose up --build -d`
- **Start services**: `docker-compose up -d`
- **Stop services**: `docker-compose down`
- **View logs**: `docker-compose logs -f`
- **Complete rebuild**: `docker-compose down -v ; docker-compose up --build -d`
- **Shell access**: `docker compose exec container-nginx-alpine1 bash`

### Testing
- **Run tests**: `npm test`
- **Run tests with coverage**: `npx jest --coverage`

The project uses Jest with jsdom environment for testing browser-based JavaScript. Test configuration is in package.json under the "jest" key.

### Access Points
- Main application: http://localhost:8090
- Drupal (if configured): http://localhost:8095 or http://127.0.0.1:8095
- Adminer: http://localhost:8092 or http://127.0.0.1:8092
- NGINX Proxy Manager: http://localhost:81 or http://127.0.0.1:81

## Architecture

### Application Structure
- **Frontend**: Pure JavaScript (no framework) with HTML/CSS
  - `index.html`: Main UI with search form and results table
  - `script.js`: Client-side logic for API calls, filtering, and rendering
  - `style.css`: Styling
  - `script.test.js`: Jest test suite for script.js functions

- **Deployment**: Docker-based with Nginx Alpine
  - `Dockerfile`: Nginx Alpine image with application files
  - `docker-compose.yml`: Service configuration for nginx container
  - Nginx serves static files and proxies are handled through environment variables

### Key Components in script.js

1. **DOM Element Caching** (lines 1-10): All UI elements are cached at module load for performance
2. **buildFilters()** (lines 48-169): Constructs API filter objects from form inputs
   - Handles complex agency/sub-agency filtering logic
   - Provides default date ranges (180 days back)
   - Supports award types: contracts, grants, IDVs with specific type codes
3. **fetchTotalCount()** (lines 173-199): Gets total record count via count API endpoint
4. **fetchResults()** (lines 203-247): Main search function that fetches paginated results
5. **renderResults()** (lines 251-351): Populates table and handles "no results" state
   - Dynamically generates USASpending.gov URLs with agency filters
6. **handlePagination()** (lines 373-387): Manages prev/next buttons and record info display

### Form Fields and API Mapping

The search form in index.html contains the following fields that map to API parameters:

#### Required Fields
- **keyword** (`#keyword`): Text input, min 3 characters
  - Maps to: `filters.keywords` (array)

- **awardType** (`#awardType`): Select dropdown with options:
  - `all_contracts` → `award_type_codes: ["A", "B", "C", "D"]`
  - `all_grants` → `award_type_codes: ["02", "03", "04", "05"]`
  - `all_idvs` → `award_type_codes: ["IDV_A", "IDV_B", "IDV_B_A", "IDV_B_B", "IDV_B_C", "IDV_C", "IDV_D", "IDV_E"]`
  - Individual types: `A` (BPA), `B` (Purchase Order), `C` (Delivery Order), `D` (Definitive Contract)
  - Grant types: `02` (Block Grant), `03` (Formula Grant), `04` (Project Grant), `05` (Cooperative Agreement)
  - IDV types: `IDV_A` (GWAC), `IDV_B` (Indefinite Delivery Vehicle)
  - Maps to: `filters.award_type_codes` (array)

#### Advanced Filters (Collapsible)

- **agencyType** (`#agencyType`): Top-tier agency selection
  - Options: DOD, DOE, GSA, VA, DHS, AG, SSA, Treasury
  - Maps to: `filters.agencies[].name` and `filters.agencies[].toptier_name` when tier is "toptier"

- **subAgencyType** (`#subAgencyType`): Sub-tier agency selection
  - Options: GSA - FAS, GSA - PBS, DOE - FERC, DHS - OPO, TREASURY - IRS, DHS - Coast Guard, DOD - DISA, DOD - DHA, DOD - WHS, USTRANSCOM, DOD - Missile Defense Agency, DOD - Department of the Navy, DOD - Department of the Air Force
  - Maps to: `filters.agencies[].name` when tier is "subtier"

- **agencyDetails** (`#agencyDetails`): Agency function
  - Options: `awarding` or `funding`
  - Maps to: `filters.agencies[].type`
  - Default: "awarding" if not specified

- **dateType** (`#dateType`): Type of date filter
  - Options: `action_date`, `date_signed`, `last_modified_date`, `new_awards_only`
  - Maps to: `filters.time_period[].date_type`

- **startDate** & **endDate** (`#startDate`, `#endDate`): Date inputs
  - Maps to: `filters.time_period[].start_date` and `filters.time_period[].end_date`
  - Default: Last 180 days if not provided (calculated by getDefaultDates())

- **placeOfPerformanceScope** (`#placeOfPerformanceScope`): Location scope
  - Options: `domestic` or `foreign`
  - Maps to: `filters.place_of_performance_scope`

- **recipientSearchText** (`#recipientSearchText`): Comma-separated recipient names
  - Maps to: `filters.recipient_search_text` (array after splitting by commas)

- **recipientScope** (`#recipientScope`): Recipient location scope
  - Options: `domestic` or `foreign`
  - Maps to: `filters.recipient_scope`

#### Agency Filter Logic (script.js lines 95-150)
The buildFilters() function has complex conditional logic for agency filters:
- If agencyType + subAgencyType + agencyDetails: Creates subtier agency filter with specified type
- If agencyType + subAgencyType: Creates subtier agency filter with type="awarding"
- If agencyType + agencyDetails: Creates toptier agency filter with specified type
- If agencyType only: Creates toptier agency filter with type="awarding"
- If subAgencyType + agencyDetails: Creates subtier agency filter with specified type
- If subAgencyType only: Creates subtier agency filter with type="awarding"

### API Integration
The app interacts with two USASpending.gov endpoints:

- **Search endpoint**: `POST /api/v2/search/spending_by_award/`
  - API URL: https://api.usaspending.gov/api/v2/search/spending_by_award/
  - Documentation: https://github.com/fedspendingtransparency/usaspending-api/blob/master/usaspending_api/api_contracts/contracts/v2/search/spending_by_award.md

- **Count endpoint**: `POST /api/v2/search/spending_by_award_count/`
  - API URL: https://api.usaspending.gov/api/v2/search/spending_by_award_count/
  - Documentation: https://github.com/fedspendingtransparency/usaspending-api/blob/master/usaspending_api/api_contracts/contracts/v2/search/spending_by_award_count.md

Both endpoints accept filter objects with: keywords, award_type_codes, time_period, agencies, place_of_performance_scope, recipient_scope, recipient_search_text

## Testing Approach

Tests use Jest with jsdom to simulate browser environment. All exported functions from script.js are tested:
- `buildFilters`: Validates filter construction logic
- `getDefaultDates`: Ensures proper date formatting
- `createLinkCell`: Tests table cell creation with links
- `handlePagination`: Validates pagination state management
- `renderResults`: Tests table rendering and "no results" handling
- `fetchTotalCount` & `fetchResults`: Mock fetch API to test async operations

When modifying script.js, ensure the module.exports block (line 390-392) includes any new testable functions.

## Important Notes

- The codebase uses CommonJS module pattern (module.exports) for Jest compatibility despite running in browser
- Environment variable `apiUrl` is passed to the nginx container but currently unused in the client code
- Multiple Docker compose files exist in subdirectories (drupal/, proxy-admin/) for additional services
- Coverage reports are generated to the coverage/ directory (ignored by git per .gitignore)
