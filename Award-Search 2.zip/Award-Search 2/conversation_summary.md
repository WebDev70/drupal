## Award-Search 2 Project Information

**Project Overview (from `GEMINI.md` context):**
This project is a static frontend web application named "Award-Search 2". Its purpose is to provide a user interface for searching US government spending awards. The application allows users to filter awards by keyword, award type, agency, date range, and other criteria. The application is built using plain HTML, CSS, and JavaScript. It directly queries the official `api.usaspending.gov` API to fetch and display award data. The project also includes a testing suite using the Jest framework to ensure the JavaScript logic is working correctly. The entire application is configured to run inside a Docker container using Nginx as a web server to serve the static files.

---

## How to Publish to AWS (Static Site - S3 & CloudFront)

Deploying this static web application to AWS can be done efficiently using Amazon S3 for hosting and Amazon CloudFront as a content delivery network (CDN).

### Part 1: Create and Configure an S3 Bucket

First, you'll set up an S3 bucket to store your website's files (`index.html`, `style.css`, `script.js`).

1.  **Sign in to the AWS Management Console** and navigate to the **S3** service.
2.  **Create a new bucket**. Give it a unique name (e.g., `my-award-search-app`).
3.  **Disable "Block all public access"**: In the "Block Public Access settings for this bucket" section, uncheck the box for **Block all public access**. You need to do this to allow users to view your website. Acknowledge the warning.
4.  **Enable static website hosting**:
    *   After creating the bucket, navigate to its **Properties** tab.
    *   Scroll down to **Static website hosting** and click **Edit**.
    *   Select **Enable**.
    *   In the **Index document** field, enter `index.html`.
    *   Save the changes.
5.  **Note the Bucket Website Endpoint**: After enabling static website hosting, you will see a **Bucket website endpoint** URL. Copy this URL; you'll need it later.

### Part 2: Upload Your Website Files

Now, upload your application files to the S3 bucket you just created.

1.  Navigate to the **Objects** tab of your S3 bucket.
2.  Click the **Upload** button.
3.  Upload the following files from your project directory:
    *   `index.html`
    *   `style.css`
    *   `script.js`
4.  **Set Permissions**: During the upload process (or after by selecting the files), you need to grant public-read access. In the **Permissions** section of the upload wizard, select **Grant public-read access**.

At this point, your website is live and accessible via the S3 bucket website endpoint you noted earlier. However, for better performance, security (HTTPS), and scalability, you should serve it through CloudFront.

### Part 3: Create a CloudFront Distribution

CloudFront will cache your website at edge locations around the world, making it faster for users.

1.  Navigate to the **CloudFront** service in the AWS Console.
2.  Click **Create a CloudFront distribution**.
3.  In the **Origin domain** field, paste the **S3 bucket website endpoint** you copied earlier. **Do not** select the S3 bucket from the dropdown list that appears, as this will not work correctly with the S3 static website configuration.
4.  **Viewer Protocol Policy**: Under **Viewer**, set the **Viewer protocol policy** to **Redirect HTTP to HTTPS** to ensure your site is served over a secure connection.
5.  **Default Root Object**: In the **Settings** section, enter `index.html` as the **Default root object**.
6.  Click **Create distribution**. The distribution will take about 15-20 minutes to deploy.
7.  Once deployed, you will get a **Distribution domain name** (e.g., `d1234abcd.cloudfront.net`). This is the final, public URL for your application.

### (Optional) Part 4: Using a Custom Domain

If you own a custom domain and want to use it for your application:

1.  **Add an SSL/TLS Certificate**: Go to **AWS Certificate Manager (ACM)** and request a public certificate for your custom domain (e.g., `search.yourdomain.com`).
2.  **Update CloudFront Distribution**: Edit your CloudFront distribution and add your custom domain as an **Alternate domain name (CNAME)**. Select the SSL certificate you created in ACM.
3.  **Configure DNS**: In your DNS provider (like Amazon Route 53), create a `CNAME` or `A` (Alias) record that points your custom domain to your CloudFront distribution domain name.

---

## How to Publish to AWS (Container-based - ECR & App Runner)

Using the `Dockerfile` offers an alternative, container-based deployment strategy on AWS.

### Part 1: Build and Push the Docker Image to Amazon ECR

First, you need to build your Docker image and store it in Amazon's container registry (ECR).

1.  **Create an ECR Repository**:
    *   In the AWS Console, navigate to **Elastic Container Registry (ECR)**.
    *   Click **Create repository**.
    *   Give it a name (e.g., `award-search-app`) and click **Create repository**.

2.  **Authenticate Docker to ECR**:
    *   Select your new repository and click the **View push commands** button.
    *   This will show you a command to run in your terminal to authenticate your Docker CLI with AWS. It will look something like this (the exact command will be in your console):
        ```bash
        aws ecr get-login-password --region your-region | docker login --username AWS --password-stdin your-aws-account-id.dkr.ecr.your-region.amazonaws.com
        ```
    *   Copy and run that command in your local terminal.

3.  **Build and Push the Image**:
    *   The push commands page in ECR will also give you the exact `docker build`, `docker tag`, and `docker push` commands to use.
    *   **Build the image**:
        ```bash
        docker build -t award-search-app .
        ```
    *   **Tag the image**:
        ```bash
        docker tag award-search-app:latest your-aws-account-id.dkr.ecr.your-region.amazonaws.com/award-search-app:latest
        ```
    *   **Push the image to ECR**:
        ```bash
        docker push your-aws-account-id.dkr.ecr.your-region.amazonaws.com/award-search-app:latest
        ```

### Part 2: Deploy the Container on AWS

Now that your image is in ECR, you can run it. **AWS App Runner** is the simplest and most direct service for this kind of web application.

1.  **Navigate to AWS App Runner**.
2.  Click **Create an App Runner service**.
3.  **Source**:
    *   Choose **Container registry** and **Amazon ECR**.
    *   For the **Container image URI**, browse and select the ECR repository and image tag (`latest`) you just pushed.
4.  **Service settings**:
    *   Give your service a name (e.g., `award-search-service`).
    *   For the **Virtual CPU & memory**, the smallest configuration is likely sufficient.
    *   In the **Port** field, enter `80`. The `Dockerfile` exposes port 80, so App Runner needs to know to send traffic there.
5.  **Review and Create**:
    *   Review the settings and click **Create service**.
    *   App Runner will deploy your container and provide you with a default domain (e.g., `https://<some-id>.awsapprunner.com`) where you can access your application.

---

## CI/CD Pipeline: GitHub PR -> Jenkins -> SonarQube -> AWS

Integrating Jenkins and SonarQube into your workflow creates a robust CI/CD pipeline that automates testing, quality analysis, and deployment.

### The CI/CD Workflow at a Glance

This is the process you're describing:

1.  **Developer**: Creates a Pull Request (PR) in GitHub.
2.  **GitHub**: Automatically triggers a Jenkins pipeline via a webhook.
3.  **Jenkins (CI - Continuous Integration)**:
    *   Checks out the PR code.
    *   Runs unit tests (`npm test`).
    *   Performs static code analysis using SonarQube.
    *   Waits for SonarQube's "Quality Gate" result.
    *   If tests or the quality gate fail, the pipeline fails and reports back to the GitHub PR.
    *   If they pass, the PR is marked as "green," ready for review.
4.  **Developer/Team Lead**: Merges the successful PR into the main branch.
5.  **GitHub**: The merge event triggers the Jenkins pipeline again.
6.  **Jenkins (CD - Continuous Deployment)**:
    *   Runs all the CI steps again on the main branch.
    *   Builds the Docker image.
    *   Pushes the image to Amazon ECR (Elastic Container Registry).
    *   Deploys the new image to AWS (e.g., using AWS App Runner).

### Core Components and Their Roles

*   **GitHub**: Your source code repository and the starting point for all CI/CD triggers.
*   **Jenkins**: The automation engine that orchestrates the entire process. It runs the steps defined in a `Jenkinsfile`.
*   **SonarQube**: Your code quality and security gatekeeper. It analyzes the code for bugs, vulnerabilities, and code smells, then provides a pass/fail "Quality Gate" status.
*   **AWS**: Your deployment target. For this workflow, **ECR** (for storing the image) and **App Runner** (for running the container) are a good fit.

### Example `Jenkinsfile`

This entire process is defined in a file called `Jenkinsfile` that you would add to your repository. Here’s a declarative example of what that file might look like:

```groovy
// Jenkinsfile

pipeline {
    // Agent defines the execution environment. Here we assume Jenkins has Docker and AWS CLI installed.
    agent any

    tools {
        // Pre-configure SonarQube Scanner and Node.js in Jenkins -> Global Tool Configuration
        nodejs 'NodeJS-18' 
    }

    environment {
        // Credentials stored securely in Jenkins
        AWS_CREDS       = credentials('your-aws-credentials-id')
        SONAR_TOKEN     = credentials('your-sonarqube-token-id')
        SONAR_HOST_URL  = "https://your-sonarqube-server.com"
        ECR_REGISTRY    = "your-aws-account-id.dkr.ecr.your-region.amazonaws.com"
        ECR_REPOSITORY  = "award-search-app"
        APP_RUNNER_ARN  = "arn:aws:apprunner:your-region:your-account-id:service/your-app/your-service-id"
    }

    stages {
        stage('Checkout') {
            steps {
                // Clones the repository code
                checkout scm
            }
        }

        stage('Install Dependencies & Run Tests') {
            steps {
                // Run the same tests you run locally
                sh 'npm install'
                sh 'npm test'
            }
        }

        stage('SonarQube Analysis') {
            steps {
                // This block configures the SonarQube scanner
                withSonarQubeEnv(server: 'your-sonarqube-server-name') {
                    sh """
                        # Run the scanner with properties for this project
                        # The scanner automatically sends the report to your SonarQube server
                        /path/to/sonar-scanner/bin/sonar-scanner \
                            -Dsonar.projectKey=award-search-project \
                            -Dsonar.sources=. \
                            -Dsonar.host.url=${SONAR_HOST_URL} \
                            -Dsonar.login=${SONAR_TOKEN}
                    """
                }
                // This crucial step makes Jenkins wait for the SonarQube analysis to complete
                // and will FAIL the pipeline if the Quality Gate is not "PASSED".
                timeout(time: 10, unit: 'MINUTES') {
                    waitForQualityGate abortPipeline: true
                }
            }
        }

        // --- The following stages only run when code is merged into the 'main' branch ---
        stage('Build and Push Docker Image') {
            when {
                // This 'when' block restricts this stage to only the main branch
                branch 'main'
            }
            steps {
                script {
                    // Log in to Amazon ECR
                    sh "aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin ${ECR_REGISTRY}"
                    
                    // Build, tag, and push the image
                    def imageName = "${ECR_REGISTRY}/${ECR_REPOSITORY}:latest"
                    sh "docker build -t ${imageName} ."
                    sh "docker push ${imageName}"
                }
            }
        }

        stage('Deploy to AWS App Runner') {
            when {
                branch 'main'
            }
            steps {
                // Tell App Runner to pull the new image from ECR and deploy it
                sh "aws apprunner start-deployment --service-arn ${APP_RUNNER_ARN}"
            }
        }
    }
}
