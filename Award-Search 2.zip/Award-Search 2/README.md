## Latest and Greatest
#### v2


#### Usage commands:
#### 0. docker-compose up --build -d
#### 1. Start: docker-compose up -d
#### 2. Stop: docker-compose down
#### 3. Logs: docker-compose logs -f
#### 4. Rebuild: docker-compose down -v ; docker-compose up --build -d
#### 5. docker compose exec 'name_of_image' bash
#### 6. Access Drupal: http://localhost:8090/
#### 7. Adminer - http://localhost:8092/
#### 8. Access WordPress: http://localhost:8000
#### 9. Access phpMyAdmin: http://localhost:8080
#### 10. Access WordPress Admin: http://localhost:8000/wp-admin/index.php
#### 11. WordPress Tutorial - https://www.rubixstudios.com.au/website-design/wordpress-docker?srsltid=AfmBOor2-wrJ0J84f-dyuD16K8J1cNt3_MIWGNgimRLZ33svWQTw4uma
#### 12. Drupal Tutorial - https://www.youtube.com/watch?v=kztDsxyesqM&t=462s
#### 13. https://nginxproxymanager.com/setup/
#### 14. git update-git-for-windows
#### 15. npm update
#### 16. ng update
#### 17. git add .
#### 18. git commit -m 'put commit message here'
#### 19. git commit -am 'YML' <-- This will stage and commit
#### 20. git push



