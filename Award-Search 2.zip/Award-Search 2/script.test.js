// Set up a basic DOM structure before requiring the script
document.body.innerHTML = `
  <div id="resultsContainer"></div>
  <table id="resultsTable"><tbody></tbody></table>
  <button id="prevButton"></button>
  <button id="nextButton"></button>
  <div id="errorMessage"></div>
  <div class="loader"></div>
  <div id="recordInfo"></div>
  <div id="totalRecordCount"></div>
  <form id="searchForm">
    <input id="keyword" />
    <input id="agencyType" />
    <input id="subAgencyType" />
    <input id="agencyDetails" />
    <input id="placeOfPerformanceScope" />
    <input id="recipientScope" />
    <input id="recipientSearchText" />
    <input id="awardType" />
    <input id="startDate" />
    <input id="endDate" />
    <input id="dateType" />
  </form>
`;

const { buildFilters, getDefaultDates, createLinkCell, handlePagination, renderResults, fetchTotalCount, fetchResults } = require('./script');

describe('buildFilters', () => {
    test('should build filters correctly with all fields', () => {
        // Set values for the mocked form elements
        document.getElementById('keyword').value = 'test keyword';
        document.getElementById('agencyType').value = 'test agency';
        document.getElementById('subAgencyType').value = 'test sub agency';
        document.getElementById('agencyDetails').value = 'test details';
        document.getElementById('placeOfPerformanceScope').value = 'test scope';
        document.getElementById('recipientScope').value = 'test recipient scope';
        document.getElementById('recipientSearchText').value = 'test, recipient, text';
        document.getElementById('awardType').value = 'A';
        document.getElementById('startDate').value = '2022-01-01';
        document.getElementById('endDate').value = '2022-12-31';
        document.getElementById('dateType').value = 'action_date';

        const filters = buildFilters();
        expect(filters).toEqual({
            keywords: ['test keyword'],
            award_type_codes: ['A'],
            time_period: [
                {
                    start_date: '2022-01-01',
                    end_date: '2022-12-31',
                    date_type: 'action_date',
                },
            ],
            agencies: [
                {
                    type: 'test details',
                    tier: 'subtier',
                    name: 'test sub agency',
                },
            ],
            place_of_performance_scope: 'test scope',
            recipient_scope: 'test recipient scope',
            recipient_search_text: ['test', 'recipient', 'text'],
        });
    });
});

describe('getDefaultDates', () => {
    test('should return the correct date format', () => {
        const { startDate, endDate } = getDefaultDates();
        const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
        expect(startDate).toMatch(dateRegex);
        expect(endDate).toMatch(dateRegex);
    });
});

describe('createLinkCell', () => {
    test('should create a cell with a link', () => {
        const cell = createLinkCell('http://example.com', 'Example');
        expect(cell.tagName).toBe('TD');
        const link = cell.querySelector('a');
        expect(link).not.toBeNull();
        expect(link.href).toBe('http://example.com/');
        expect(link.textContent).toBe('Example');
        expect(link.target).toBe('_blank');
        expect(link.rel).toBe('noopener noreferrer');
    });

    test('should create a cell with fallback text', () => {
        const cell = createLinkCell(null, null, 'N/A');
        expect(cell.tagName).toBe('TD');
        expect(cell.textContent).toBe('N/A');
        expect(cell.querySelector('a')).toBeNull();
    });
});

describe('handlePagination', () => {
    test('should handle first page correctly', () => {
        const data = {
            page_metadata: { hasNext: true, page: 1 },
            results: new Array(10),
        };
        handlePagination(data);
        expect(document.getElementById('recordInfo').textContent).toBe('Showing records 1 to 10 on page 1');
        expect(document.getElementById('prevButton').disabled).toBe(true);
        expect(document.getElementById('nextButton').disabled).toBe(false);
    });

    test('should handle middle page correctly', () => {
        const data = {
            page_metadata: { hasNext: true, page: 2 },
            results: new Array(10),
        };
        handlePagination(data);
        expect(document.getElementById('recordInfo').textContent).toBe('Showing records 11 to 20 on page 2');
        expect(document.getElementById('prevButton').disabled).toBe(false);
        expect(document.getElementById('nextButton').disabled).toBe(false);
    });

    test('should handle last page correctly', () => {
        const data = {
            page_metadata: { hasNext: false, page: 3 },
            results: new Array(5),
        };
        handlePagination(data);
        expect(document.getElementById('recordInfo').textContent).toBe('Showing records 21 to 25 on page 3');
        expect(document.getElementById('prevButton').disabled).toBe(false);
        expect(document.getElementById('nextButton').disabled).toBe(true);
    });
});

describe('renderResults', () => {
    beforeEach(() => {
        // Reset the table and error message before each test
        document.getElementById('resultsTable').querySelector('tbody').innerHTML = '';
        document.getElementById('errorMessage').textContent = '';
    });

    test('should display "No results found" message', () => {
        const data = { results: [] };
        renderResults(data);
        const tableBody = document.getElementById('resultsTable').querySelector('tbody');
        expect(tableBody.rows.length).toBe(1);
        expect(tableBody.rows[0].cells[0].textContent).toBe('No results found. Please try a different search.');
    });

    test('should render results in the table', () => {
        const data = {
            results: [
                {
                    'Recipient Name': 'Test Corp',
                    'generated_internal_id': '123',
                    'Award ID': 'AWARD001',
                    'Award Type': 'Contract',
                    'Description': 'Test description',
                    'Award Amount': 1000,
                },
            ],
            page_metadata: { hasNext: false, page: 1 },
        };
        renderResults(data);
        const tableBody = document.getElementById('resultsTable').querySelector('tbody');
        expect(tableBody.rows.length).toBe(1);
        const row = tableBody.rows[0];
        expect(row.cells[0].textContent).toBe('Test Corp');
        expect(row.cells[1].textContent).toBe('AWARD001');
        expect(row.cells[2].textContent).toBe('Contract');
        expect(row.cells[3].textContent).toBe('Test description');
        expect(row.cells[4].textContent).toBe('$1,000');
    });
});

describe('fetchTotalCount', () => {
    beforeEach(() => {
        global.fetch = jest.fn();
    });

    test('should fetch and return the total count', async () => {
        const mockResponse = {
            ok: true,
            json: jest.fn().mockResolvedValue({
                results: {
                    contracts: 10,
                    idvs: 5,
                    grants: 2,
                },
            }),
        };
        global.fetch.mockResolvedValue(mockResponse);

        const filters = { award_type_codes: ['A', 'B'] };
        const totalCount = await fetchTotalCount(filters);

        expect(global.fetch).toHaveBeenCalledWith(
            'https://api.usaspending.gov/api/v2/search/spending_by_award_count/',
            expect.any(Object)
        );
        expect(totalCount).toBe(17);
    });

    test('should handle API errors gracefully', async () => {
        const mockResponse = {
            ok: false,
            json: jest.fn().mockResolvedValue({ detail: 'An error occurred.' }),
        };
        global.fetch.mockResolvedValue(mockResponse);

        const filters = { award_type_codes: ['A', 'B'] };
        const totalCount = await fetchTotalCount(filters);

        expect(totalCount).toBe(0);
    });
});

describe('fetchResults', () => {
    beforeEach(() => {
        global.fetch = jest.fn();
        document.getElementById('totalRecordCount').textContent = '';
        document.getElementById('errorMessage').textContent = '';
    });

    test('should fetch results and render them', async () => {
        const mockCountResponse = {
            ok: true,
            json: jest.fn().mockResolvedValue({ results: { contracts: 1 } }),
        };
        const mockResultsResponse = {
            ok: true,
            json: jest.fn().mockResolvedValue({
                results: [
                    {
                        'Recipient Name': 'Test Corp',
                        'generated_internal_id': '123',
                        'Award ID': 'AWARD001',
                        'Award Type': 'Contract',
                        'Description': 'Test description',
                        'Award Amount': 1000,
                    },
                ],
                page_metadata: { hasNext: false, page: 1 },
            }),
        };
        global.fetch.mockResolvedValueOnce(mockCountResponse).mockResolvedValueOnce(mockResultsResponse);

        await fetchResults();

        expect(document.getElementById('totalRecordCount').textContent).toBe('Total Records: 1');
        const tableBody = document.getElementById('resultsTable').querySelector('tbody');
        expect(tableBody.rows.length).toBe(1);
        expect(tableBody.rows[0].cells[0].textContent).toBe('Test Corp');
    });

    test('should handle errors during fetch', async () => {
        const mockErrorResponse = {
            ok: false,
            json: jest.fn().mockResolvedValue({ detail: 'An error occurred.' }),
        };
        global.fetch.mockResolvedValue(mockErrorResponse);

        await fetchResults();

        expect(document.getElementById('errorMessage').textContent).toBe('An error occurred.');
    });
});
