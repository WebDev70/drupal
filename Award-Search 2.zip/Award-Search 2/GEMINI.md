# GEMINI Project Analysis: Award-Search 2

## Project Overview

This project is a static frontend web application named "Award-Search 2". Its purpose is to provide a user interface for searching US government spending awards. The application allows users to filter awards by keyword, award type, agency, date range, and other criteria.

The application is built using plain HTML, CSS, and JavaScript. It directly queries the official `api.usaspending.gov` API to fetch and display award data. The project also includes a testing suite using the Jest framework to ensure the JavaScript logic is working correctly.

The entire application is configured to run inside a Docker container using Nginx as a web server to serve the static files.

## Building and Running

### Running the Application

The primary method for running this application is by using Docker Compose.

1.  **Build and start the container:**
    ```bash
    docker-compose up --build -d
    ```

2.  **Access the application:**
    Once the container is running, the application should be accessible at [http://localhost:8090](http://localhost:8090).

### Running Tests

The project uses Jest for testing the JavaScript code.

1.  **Install dependencies:**
    ```bash
    npm install
    ```

2.  **Run the tests:**
    ```bash
    npm test
    ```

## Development Conventions

*   **API Interaction:** All API interactions are handled on the client-side in `script.js`. The application makes POST requests to the `https://api.usaspending.gov/api/v2/search/spending_by_award/` and `https://api.usaspending.gov/api/v2/search/spending_by_award_count/` endpoints.
*   **Testing:** JavaScript code in `script.js` is tested using Jest. The tests are located in `script.test.js` and mock the DOM and `fetch` API to verify the application's logic in isolation.
*   **Containerization:** The project is containerized using Docker and Nginx. The `Dockerfile` sets up an Nginx server and copies the project files into the web root. The `docker-compose.yml` file orchestrates the `nginx` service.
*   **Miscellany:** The `README.md` and `docker-compose.yml` files contain a large number of commented-out commands and links. This suggests the project might also serve as a learning environment or a personal cheatsheet for various technologies like Drupal, WordPress, Angular, and Capacitor.
