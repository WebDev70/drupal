This is a multiple container project consisting of Drupal, MariaDB, and Adminer. 

This is deployed to Google Cloud via Google build to GKE.